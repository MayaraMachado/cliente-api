from django.apps import AppConfig


class EnderecoConfig(AppConfig):
    name = 'endereco'
